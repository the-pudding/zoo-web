// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"hZBy":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.select = select;
exports.selectAll = selectAll;
exports.find = find;
exports.removeClass = removeClass;
exports.addClass = addClass;
exports.hasClass = hasClass;
exports.jumpTo = jumpTo;

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

// DOM helper functions
// public
function select(selector) {
  return document.querySelector(selector);
}

function selectAll(selector) {
  var parent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return _toConsumableArray(parent.querySelectorAll(selector));
}

function find(el, selector) {
  return _toConsumableArray(el.querySelectorAll(selector));
}

function removeClass(el, className) {
  if (el.classList) el.classList.remove(className);else el.className = el.className.replace(new RegExp("(^|\\b)".concat(className.split(' ').join('|'), "(\\b|$)"), 'gi'), ' ');
}

function addClass(el, className) {
  if (el.classList) el.classList.add(className);else el.className = "".concat(el.className, " ").concat(className);
}

function hasClass(el, className) {
  if (el.classList) return el.classList.contains(className);
  return new RegExp("(^| )".concat(className, "( |$)"), 'gi').test(el.className);
}

function jumpTo(el, offset) {
  offset = offset || 0;
  var top = el.getBoundingClientRect().top + offset;
  var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  var destY = scrollTop + top;
  window.scrollTo(0, destY);
}
},{}],"U9xJ":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = linkFix;

var _dom = require("./dom");

/**
 * Fixes target blanks links
 */
function linkFix() {
  var links = (0, _dom.selectAll)("[target='_blank']");
  links.forEach(function (link) {
    return link.setAttribute("rel", "noopener");
  });
}
},{"./dom":"hZBy"}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = loadData;

/* global d3 */

/* usage
	import loadData from './load-data'
	
	loadData('file.csv').then(result => {
		console.log(result);
	}).catch(console.error);

	loadData(['file1.csv', 'file2.json]).then(result => {
		console.log(result);
	}).catch(console.error);
*/
function loadFile(file) {
  return new Promise(function (resolve, reject) {
    var ext = file.split('.').pop();
    if (ext === 'csv') d3.csv("".concat(file)).then(resolve).catch(reject);else if (ext === 'json' || ext === 'geojson') d3.json("assets/data/".concat(file)).then(resolve).catch(reject);else reject(new Error("unsupported file type for: ".concat(file)));
  });
}

function loadData(files) {
  if (typeof files === 'string') return loadFile(files);
  var loads = files.map(loadFile);
  return Promise.all(loads);
}
},{}],"TAPd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $section = d3.select('.grid');
var data = [];

function resize() {}

function swapSource() {
  var $sel = d3.select(this);
  var id = $sel.attr('data-id');
  var type = $sel.attr('data-type');

  if (type === 'png') {
    $sel.attr('src', "https://pudding-data-processing.s3.amazonaws.com/zoo-cams/output/".concat(id, ".gif"));
    $sel.attr('data-type', 'gif');
  } else {
    $sel.attr('src', "https://pudding-data-processing.s3.amazonaws.com/zoo-cams/stills/".concat(id, ".png"));
    $sel.attr('data-type', 'png');
  }
}

function setup() {
  var $group = $section.selectAll('.cam').data(data).join(function (enter) {
    var div = enter.append('div').attr('class', function (d) {
      return "cam cam--".concat(d.id);
    });
    var image = div.append('img').attr('class', 'cam__display').attr('data-id', function (d) {
      return d.id;
    }).attr('data-type', 'png').attr('src', function (d) {
      return "https://pudding-data-processing.s3.amazonaws.com/zoo-cams/stills/".concat(d.id, ".png");
    });
    div.append('p').text(function (d) {
      return "ID: ".concat(d.id);
    });
    div.append('p').text(function (d) {
      return d.animal;
    });
    div.append('p').text(function (d) {
      return d.facility;
    });
    image.on('click', swapSource);
  });
}

function init() {
  (0, _loadData.default)('https://raw.githubusercontent.com/the-pudding/zoo-data/master/zoos.csv').then(function (res) {
    data = res;
    setup();
  });
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./load-data":"xZJw"}],"VKu2":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/**
 * Load an image
 * @param {string} url path to image
 */
function loadImage(url) {
  return new Promise(function (resolve, reject) {
    var img = new Image();

    img.onload = function () {
      return resolve(img);
    };

    img.onerror = function () {
      return reject("error loading ".concat(url));
    };

    img.src = url;
  });
}

var _default = loadImage;
exports.default = _default;
},{}],"CRRU":[function(require,module,exports) {
/**
 * Copyright 2016 Google Inc. All Rights Reserved.
 *
 * Licensed under the W3C SOFTWARE AND DOCUMENT NOTICE AND LICENSE.
 *
 *  https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document
 *
 */
(function() {
'use strict';

// Exit early if we're not running in a browser.
if (typeof window !== 'object') {
  return;
}

// Exit early if all IntersectionObserver and IntersectionObserverEntry
// features are natively supported.
if ('IntersectionObserver' in window &&
    'IntersectionObserverEntry' in window &&
    'intersectionRatio' in window.IntersectionObserverEntry.prototype) {

  // Minimal polyfill for Edge 15's lack of `isIntersecting`
  // See: https://github.com/w3c/IntersectionObserver/issues/211
  if (!('isIntersecting' in window.IntersectionObserverEntry.prototype)) {
    Object.defineProperty(window.IntersectionObserverEntry.prototype,
      'isIntersecting', {
      get: function () {
        return this.intersectionRatio > 0;
      }
    });
  }
  return;
}

/**
 * Returns the embedding frame element, if any.
 * @param {!Document} doc
 * @return {!Element}
 */
function getFrameElement(doc) {
  try {
    return doc.defaultView && doc.defaultView.frameElement || null;
  } catch (e) {
    // Ignore the error.
    return null;
  }
}

/**
 * A local reference to the root document.
 */
var document = (function(startDoc) {
  var doc = startDoc;
  var frame = getFrameElement(doc);
  while (frame) {
    doc = frame.ownerDocument;
    frame = getFrameElement(doc);
  }
  return doc;
})(window.document);

/**
 * An IntersectionObserver registry. This registry exists to hold a strong
 * reference to IntersectionObserver instances currently observing a target
 * element. Without this registry, instances without another reference may be
 * garbage collected.
 */
var registry = [];

/**
 * The signal updater for cross-origin intersection. When not null, it means
 * that the polyfill is configured to work in a cross-origin mode.
 * @type {function(DOMRect|ClientRect, DOMRect|ClientRect)}
 */
var crossOriginUpdater = null;

/**
 * The current cross-origin intersection. Only used in the cross-origin mode.
 * @type {DOMRect|ClientRect}
 */
var crossOriginRect = null;


/**
 * Creates the global IntersectionObserverEntry constructor.
 * https://w3c.github.io/IntersectionObserver/#intersection-observer-entry
 * @param {Object} entry A dictionary of instance properties.
 * @constructor
 */
function IntersectionObserverEntry(entry) {
  this.time = entry.time;
  this.target = entry.target;
  this.rootBounds = ensureDOMRect(entry.rootBounds);
  this.boundingClientRect = ensureDOMRect(entry.boundingClientRect);
  this.intersectionRect = ensureDOMRect(entry.intersectionRect || getEmptyRect());
  this.isIntersecting = !!entry.intersectionRect;

  // Calculates the intersection ratio.
  var targetRect = this.boundingClientRect;
  var targetArea = targetRect.width * targetRect.height;
  var intersectionRect = this.intersectionRect;
  var intersectionArea = intersectionRect.width * intersectionRect.height;

  // Sets intersection ratio.
  if (targetArea) {
    // Round the intersection ratio to avoid floating point math issues:
    // https://github.com/w3c/IntersectionObserver/issues/324
    this.intersectionRatio = Number((intersectionArea / targetArea).toFixed(4));
  } else {
    // If area is zero and is intersecting, sets to 1, otherwise to 0
    this.intersectionRatio = this.isIntersecting ? 1 : 0;
  }
}


/**
 * Creates the global IntersectionObserver constructor.
 * https://w3c.github.io/IntersectionObserver/#intersection-observer-interface
 * @param {Function} callback The function to be invoked after intersection
 *     changes have queued. The function is not invoked if the queue has
 *     been emptied by calling the `takeRecords` method.
 * @param {Object=} opt_options Optional configuration options.
 * @constructor
 */
function IntersectionObserver(callback, opt_options) {

  var options = opt_options || {};

  if (typeof callback != 'function') {
    throw new Error('callback must be a function');
  }

  if (options.root && options.root.nodeType != 1) {
    throw new Error('root must be an Element');
  }

  // Binds and throttles `this._checkForIntersections`.
  this._checkForIntersections = throttle(
      this._checkForIntersections.bind(this), this.THROTTLE_TIMEOUT);

  // Private properties.
  this._callback = callback;
  this._observationTargets = [];
  this._queuedEntries = [];
  this._rootMarginValues = this._parseRootMargin(options.rootMargin);

  // Public properties.
  this.thresholds = this._initThresholds(options.threshold);
  this.root = options.root || null;
  this.rootMargin = this._rootMarginValues.map(function(margin) {
    return margin.value + margin.unit;
  }).join(' ');

  /** @private @const {!Array<!Document>} */
  this._monitoringDocuments = [];
  /** @private @const {!Array<function()>} */
  this._monitoringUnsubscribes = [];
}


/**
 * The minimum interval within which the document will be checked for
 * intersection changes.
 */
IntersectionObserver.prototype.THROTTLE_TIMEOUT = 100;


/**
 * The frequency in which the polyfill polls for intersection changes.
 * this can be updated on a per instance basis and must be set prior to
 * calling `observe` on the first target.
 */
IntersectionObserver.prototype.POLL_INTERVAL = null;

/**
 * Use a mutation observer on the root element
 * to detect intersection changes.
 */
IntersectionObserver.prototype.USE_MUTATION_OBSERVER = true;


/**
 * Sets up the polyfill in the cross-origin mode. The result is the
 * updater function that accepts two arguments: `boundingClientRect` and
 * `intersectionRect` - just as these fields would be available to the
 * parent via `IntersectionObserverEntry`. This function should be called
 * each time the iframe receives intersection information from the parent
 * window, e.g. via messaging.
 * @return {function(DOMRect|ClientRect, DOMRect|ClientRect)}
 */
IntersectionObserver._setupCrossOriginUpdater = function() {
  if (!crossOriginUpdater) {
    /**
     * @param {DOMRect|ClientRect} boundingClientRect
     * @param {DOMRect|ClientRect} intersectionRect
     */
    crossOriginUpdater = function(boundingClientRect, intersectionRect) {
      if (!boundingClientRect || !intersectionRect) {
        crossOriginRect = getEmptyRect();
      } else {
        crossOriginRect = convertFromParentRect(boundingClientRect, intersectionRect);
      }
      registry.forEach(function(observer) {
        observer._checkForIntersections();
      });
    };
  }
  return crossOriginUpdater;
};


/**
 * Resets the cross-origin mode.
 */
IntersectionObserver._resetCrossOriginUpdater = function() {
  crossOriginUpdater = null;
  crossOriginRect = null;
};


/**
 * Starts observing a target element for intersection changes based on
 * the thresholds values.
 * @param {Element} target The DOM element to observe.
 */
IntersectionObserver.prototype.observe = function(target) {
  var isTargetAlreadyObserved = this._observationTargets.some(function(item) {
    return item.element == target;
  });

  if (isTargetAlreadyObserved) {
    return;
  }

  if (!(target && target.nodeType == 1)) {
    throw new Error('target must be an Element');
  }

  this._registerInstance();
  this._observationTargets.push({element: target, entry: null});
  this._monitorIntersections(target.ownerDocument);
  this._checkForIntersections();
};


/**
 * Stops observing a target element for intersection changes.
 * @param {Element} target The DOM element to observe.
 */
IntersectionObserver.prototype.unobserve = function(target) {
  this._observationTargets =
      this._observationTargets.filter(function(item) {
        return item.element != target;
      });
  this._unmonitorIntersections(target.ownerDocument);
  if (this._observationTargets.length == 0) {
    this._unregisterInstance();
  }
};


/**
 * Stops observing all target elements for intersection changes.
 */
IntersectionObserver.prototype.disconnect = function() {
  this._observationTargets = [];
  this._unmonitorAllIntersections();
  this._unregisterInstance();
};


/**
 * Returns any queue entries that have not yet been reported to the
 * callback and clears the queue. This can be used in conjunction with the
 * callback to obtain the absolute most up-to-date intersection information.
 * @return {Array} The currently queued entries.
 */
IntersectionObserver.prototype.takeRecords = function() {
  var records = this._queuedEntries.slice();
  this._queuedEntries = [];
  return records;
};


/**
 * Accepts the threshold value from the user configuration object and
 * returns a sorted array of unique threshold values. If a value is not
 * between 0 and 1 and error is thrown.
 * @private
 * @param {Array|number=} opt_threshold An optional threshold value or
 *     a list of threshold values, defaulting to [0].
 * @return {Array} A sorted list of unique and valid threshold values.
 */
IntersectionObserver.prototype._initThresholds = function(opt_threshold) {
  var threshold = opt_threshold || [0];
  if (!Array.isArray(threshold)) threshold = [threshold];

  return threshold.sort().filter(function(t, i, a) {
    if (typeof t != 'number' || isNaN(t) || t < 0 || t > 1) {
      throw new Error('threshold must be a number between 0 and 1 inclusively');
    }
    return t !== a[i - 1];
  });
};


/**
 * Accepts the rootMargin value from the user configuration object
 * and returns an array of the four margin values as an object containing
 * the value and unit properties. If any of the values are not properly
 * formatted or use a unit other than px or %, and error is thrown.
 * @private
 * @param {string=} opt_rootMargin An optional rootMargin value,
 *     defaulting to '0px'.
 * @return {Array<Object>} An array of margin objects with the keys
 *     value and unit.
 */
IntersectionObserver.prototype._parseRootMargin = function(opt_rootMargin) {
  var marginString = opt_rootMargin || '0px';
  var margins = marginString.split(/\s+/).map(function(margin) {
    var parts = /^(-?\d*\.?\d+)(px|%)$/.exec(margin);
    if (!parts) {
      throw new Error('rootMargin must be specified in pixels or percent');
    }
    return {value: parseFloat(parts[1]), unit: parts[2]};
  });

  // Handles shorthand.
  margins[1] = margins[1] || margins[0];
  margins[2] = margins[2] || margins[0];
  margins[3] = margins[3] || margins[1];

  return margins;
};


/**
 * Starts polling for intersection changes if the polling is not already
 * happening, and if the page's visibility state is visible.
 * @param {!Document} doc
 * @private
 */
IntersectionObserver.prototype._monitorIntersections = function(doc) {
  var win = doc.defaultView;
  if (!win) {
    // Already destroyed.
    return;
  }
  if (this._monitoringDocuments.indexOf(doc) != -1) {
    // Already monitoring.
    return;
  }

  // Private state for monitoring.
  var callback = this._checkForIntersections;
  var monitoringInterval = null;
  var domObserver = null;

  // If a poll interval is set, use polling instead of listening to
  // resize and scroll events or DOM mutations.
  if (this.POLL_INTERVAL) {
    monitoringInterval = win.setInterval(callback, this.POLL_INTERVAL);
  } else {
    addEvent(win, 'resize', callback, true);
    addEvent(doc, 'scroll', callback, true);
    if (this.USE_MUTATION_OBSERVER && 'MutationObserver' in win) {
      domObserver = new win.MutationObserver(callback);
      domObserver.observe(doc, {
        attributes: true,
        childList: true,
        characterData: true,
        subtree: true
      });
    }
  }

  this._monitoringDocuments.push(doc);
  this._monitoringUnsubscribes.push(function() {
    // Get the window object again. When a friendly iframe is destroyed, it
    // will be null.
    var win = doc.defaultView;

    if (win) {
      if (monitoringInterval) {
        win.clearInterval(monitoringInterval);
      }
      removeEvent(win, 'resize', callback, true);
    }

    removeEvent(doc, 'scroll', callback, true);
    if (domObserver) {
      domObserver.disconnect();
    }
  });

  // Also monitor the parent.
  if (doc != (this.root && this.root.ownerDocument || document)) {
    var frame = getFrameElement(doc);
    if (frame) {
      this._monitorIntersections(frame.ownerDocument);
    }
  }
};


/**
 * Stops polling for intersection changes.
 * @param {!Document} doc
 * @private
 */
IntersectionObserver.prototype._unmonitorIntersections = function(doc) {
  var index = this._monitoringDocuments.indexOf(doc);
  if (index == -1) {
    return;
  }

  var rootDoc = (this.root && this.root.ownerDocument || document);

  // Check if any dependent targets are still remaining.
  var hasDependentTargets =
      this._observationTargets.some(function(item) {
        var itemDoc = item.element.ownerDocument;
        // Target is in this context.
        if (itemDoc == doc) {
          return true;
        }
        // Target is nested in this context.
        while (itemDoc && itemDoc != rootDoc) {
          var frame = getFrameElement(itemDoc);
          itemDoc = frame && frame.ownerDocument;
          if (itemDoc == doc) {
            return true;
          }
        }
        return false;
      });
  if (hasDependentTargets) {
    return;
  }

  // Unsubscribe.
  var unsubscribe = this._monitoringUnsubscribes[index];
  this._monitoringDocuments.splice(index, 1);
  this._monitoringUnsubscribes.splice(index, 1);
  unsubscribe();

  // Also unmonitor the parent.
  if (doc != rootDoc) {
    var frame = getFrameElement(doc);
    if (frame) {
      this._unmonitorIntersections(frame.ownerDocument);
    }
  }
};


/**
 * Stops polling for intersection changes.
 * @param {!Document} doc
 * @private
 */
IntersectionObserver.prototype._unmonitorAllIntersections = function() {
  var unsubscribes = this._monitoringUnsubscribes.slice(0);
  this._monitoringDocuments.length = 0;
  this._monitoringUnsubscribes.length = 0;
  for (var i = 0; i < unsubscribes.length; i++) {
    unsubscribes[i]();
  }
};


/**
 * Scans each observation target for intersection changes and adds them
 * to the internal entries queue. If new entries are found, it
 * schedules the callback to be invoked.
 * @private
 */
IntersectionObserver.prototype._checkForIntersections = function() {
  if (!this.root && crossOriginUpdater && !crossOriginRect) {
    // Cross origin monitoring, but no initial data available yet.
    return;
  }

  var rootIsInDom = this._rootIsInDom();
  var rootRect = rootIsInDom ? this._getRootRect() : getEmptyRect();

  this._observationTargets.forEach(function(item) {
    var target = item.element;
    var targetRect = getBoundingClientRect(target);
    var rootContainsTarget = this._rootContainsTarget(target);
    var oldEntry = item.entry;
    var intersectionRect = rootIsInDom && rootContainsTarget &&
        this._computeTargetAndRootIntersection(target, targetRect, rootRect);

    var newEntry = item.entry = new IntersectionObserverEntry({
      time: now(),
      target: target,
      boundingClientRect: targetRect,
      rootBounds: crossOriginUpdater && !this.root ? null : rootRect,
      intersectionRect: intersectionRect
    });

    if (!oldEntry) {
      this._queuedEntries.push(newEntry);
    } else if (rootIsInDom && rootContainsTarget) {
      // If the new entry intersection ratio has crossed any of the
      // thresholds, add a new entry.
      if (this._hasCrossedThreshold(oldEntry, newEntry)) {
        this._queuedEntries.push(newEntry);
      }
    } else {
      // If the root is not in the DOM or target is not contained within
      // root but the previous entry for this target had an intersection,
      // add a new record indicating removal.
      if (oldEntry && oldEntry.isIntersecting) {
        this._queuedEntries.push(newEntry);
      }
    }
  }, this);

  if (this._queuedEntries.length) {
    this._callback(this.takeRecords(), this);
  }
};


/**
 * Accepts a target and root rect computes the intersection between then
 * following the algorithm in the spec.
 * TODO(philipwalton): at this time clip-path is not considered.
 * https://w3c.github.io/IntersectionObserver/#calculate-intersection-rect-algo
 * @param {Element} target The target DOM element
 * @param {Object} targetRect The bounding rect of the target.
 * @param {Object} rootRect The bounding rect of the root after being
 *     expanded by the rootMargin value.
 * @return {?Object} The final intersection rect object or undefined if no
 *     intersection is found.
 * @private
 */
IntersectionObserver.prototype._computeTargetAndRootIntersection =
    function(target, targetRect, rootRect) {
  // If the element isn't displayed, an intersection can't happen.
  if (window.getComputedStyle(target).display == 'none') return;

  var intersectionRect = targetRect;
  var parent = getParentNode(target);
  var atRoot = false;

  while (!atRoot && parent) {
    var parentRect = null;
    var parentComputedStyle = parent.nodeType == 1 ?
        window.getComputedStyle(parent) : {};

    // If the parent isn't displayed, an intersection can't happen.
    if (parentComputedStyle.display == 'none') return null;

    if (parent == this.root || parent.nodeType == /* DOCUMENT */ 9) {
      atRoot = true;
      if (parent == this.root || parent == document) {
        if (crossOriginUpdater && !this.root) {
          if (!crossOriginRect ||
              crossOriginRect.width == 0 && crossOriginRect.height == 0) {
            // A 0-size cross-origin intersection means no-intersection.
            parent = null;
            parentRect = null;
            intersectionRect = null;
          } else {
            parentRect = crossOriginRect;
          }
        } else {
          parentRect = rootRect;
        }
      } else {
        // Check if there's a frame that can be navigated to.
        var frame = getParentNode(parent);
        var frameRect = frame && getBoundingClientRect(frame);
        var frameIntersect =
            frame &&
            this._computeTargetAndRootIntersection(frame, frameRect, rootRect);
        if (frameRect && frameIntersect) {
          parent = frame;
          parentRect = convertFromParentRect(frameRect, frameIntersect);
        } else {
          parent = null;
          intersectionRect = null;
        }
      }
    } else {
      // If the element has a non-visible overflow, and it's not the <body>
      // or <html> element, update the intersection rect.
      // Note: <body> and <html> cannot be clipped to a rect that's not also
      // the document rect, so no need to compute a new intersection.
      var doc = parent.ownerDocument;
      if (parent != doc.body &&
          parent != doc.documentElement &&
          parentComputedStyle.overflow != 'visible') {
        parentRect = getBoundingClientRect(parent);
      }
    }

    // If either of the above conditionals set a new parentRect,
    // calculate new intersection data.
    if (parentRect) {
      intersectionRect = computeRectIntersection(parentRect, intersectionRect);
    }
    if (!intersectionRect) break;
    parent = parent && getParentNode(parent);
  }
  return intersectionRect;
};


/**
 * Returns the root rect after being expanded by the rootMargin value.
 * @return {ClientRect} The expanded root rect.
 * @private
 */
IntersectionObserver.prototype._getRootRect = function() {
  var rootRect;
  if (this.root) {
    rootRect = getBoundingClientRect(this.root);
  } else {
    // Use <html>/<body> instead of window since scroll bars affect size.
    var html = document.documentElement;
    var body = document.body;
    rootRect = {
      top: 0,
      left: 0,
      right: html.clientWidth || body.clientWidth,
      width: html.clientWidth || body.clientWidth,
      bottom: html.clientHeight || body.clientHeight,
      height: html.clientHeight || body.clientHeight
    };
  }
  return this._expandRectByRootMargin(rootRect);
};


/**
 * Accepts a rect and expands it by the rootMargin value.
 * @param {DOMRect|ClientRect} rect The rect object to expand.
 * @return {ClientRect} The expanded rect.
 * @private
 */
IntersectionObserver.prototype._expandRectByRootMargin = function(rect) {
  var margins = this._rootMarginValues.map(function(margin, i) {
    return margin.unit == 'px' ? margin.value :
        margin.value * (i % 2 ? rect.width : rect.height) / 100;
  });
  var newRect = {
    top: rect.top - margins[0],
    right: rect.right + margins[1],
    bottom: rect.bottom + margins[2],
    left: rect.left - margins[3]
  };
  newRect.width = newRect.right - newRect.left;
  newRect.height = newRect.bottom - newRect.top;

  return newRect;
};


/**
 * Accepts an old and new entry and returns true if at least one of the
 * threshold values has been crossed.
 * @param {?IntersectionObserverEntry} oldEntry The previous entry for a
 *    particular target element or null if no previous entry exists.
 * @param {IntersectionObserverEntry} newEntry The current entry for a
 *    particular target element.
 * @return {boolean} Returns true if a any threshold has been crossed.
 * @private
 */
IntersectionObserver.prototype._hasCrossedThreshold =
    function(oldEntry, newEntry) {

  // To make comparing easier, an entry that has a ratio of 0
  // but does not actually intersect is given a value of -1
  var oldRatio = oldEntry && oldEntry.isIntersecting ?
      oldEntry.intersectionRatio || 0 : -1;
  var newRatio = newEntry.isIntersecting ?
      newEntry.intersectionRatio || 0 : -1;

  // Ignore unchanged ratios
  if (oldRatio === newRatio) return;

  for (var i = 0; i < this.thresholds.length; i++) {
    var threshold = this.thresholds[i];

    // Return true if an entry matches a threshold or if the new ratio
    // and the old ratio are on the opposite sides of a threshold.
    if (threshold == oldRatio || threshold == newRatio ||
        threshold < oldRatio !== threshold < newRatio) {
      return true;
    }
  }
};


/**
 * Returns whether or not the root element is an element and is in the DOM.
 * @return {boolean} True if the root element is an element and is in the DOM.
 * @private
 */
IntersectionObserver.prototype._rootIsInDom = function() {
  return !this.root || containsDeep(document, this.root);
};


/**
 * Returns whether or not the target element is a child of root.
 * @param {Element} target The target element to check.
 * @return {boolean} True if the target element is a child of root.
 * @private
 */
IntersectionObserver.prototype._rootContainsTarget = function(target) {
  return containsDeep(this.root || document, target) &&
    (!this.root || this.root.ownerDocument == target.ownerDocument);
};


/**
 * Adds the instance to the global IntersectionObserver registry if it isn't
 * already present.
 * @private
 */
IntersectionObserver.prototype._registerInstance = function() {
  if (registry.indexOf(this) < 0) {
    registry.push(this);
  }
};


/**
 * Removes the instance from the global IntersectionObserver registry.
 * @private
 */
IntersectionObserver.prototype._unregisterInstance = function() {
  var index = registry.indexOf(this);
  if (index != -1) registry.splice(index, 1);
};


/**
 * Returns the result of the performance.now() method or null in browsers
 * that don't support the API.
 * @return {number} The elapsed time since the page was requested.
 */
function now() {
  return window.performance && performance.now && performance.now();
}


/**
 * Throttles a function and delays its execution, so it's only called at most
 * once within a given time period.
 * @param {Function} fn The function to throttle.
 * @param {number} timeout The amount of time that must pass before the
 *     function can be called again.
 * @return {Function} The throttled function.
 */
function throttle(fn, timeout) {
  var timer = null;
  return function () {
    if (!timer) {
      timer = setTimeout(function() {
        fn();
        timer = null;
      }, timeout);
    }
  };
}


/**
 * Adds an event handler to a DOM node ensuring cross-browser compatibility.
 * @param {Node} node The DOM node to add the event handler to.
 * @param {string} event The event name.
 * @param {Function} fn The event handler to add.
 * @param {boolean} opt_useCapture Optionally adds the even to the capture
 *     phase. Note: this only works in modern browsers.
 */
function addEvent(node, event, fn, opt_useCapture) {
  if (typeof node.addEventListener == 'function') {
    node.addEventListener(event, fn, opt_useCapture || false);
  }
  else if (typeof node.attachEvent == 'function') {
    node.attachEvent('on' + event, fn);
  }
}


/**
 * Removes a previously added event handler from a DOM node.
 * @param {Node} node The DOM node to remove the event handler from.
 * @param {string} event The event name.
 * @param {Function} fn The event handler to remove.
 * @param {boolean} opt_useCapture If the event handler was added with this
 *     flag set to true, it should be set to true here in order to remove it.
 */
function removeEvent(node, event, fn, opt_useCapture) {
  if (typeof node.removeEventListener == 'function') {
    node.removeEventListener(event, fn, opt_useCapture || false);
  }
  else if (typeof node.detatchEvent == 'function') {
    node.detatchEvent('on' + event, fn);
  }
}


/**
 * Returns the intersection between two rect objects.
 * @param {Object} rect1 The first rect.
 * @param {Object} rect2 The second rect.
 * @return {?Object|?ClientRect} The intersection rect or undefined if no
 *     intersection is found.
 */
function computeRectIntersection(rect1, rect2) {
  var top = Math.max(rect1.top, rect2.top);
  var bottom = Math.min(rect1.bottom, rect2.bottom);
  var left = Math.max(rect1.left, rect2.left);
  var right = Math.min(rect1.right, rect2.right);
  var width = right - left;
  var height = bottom - top;

  return (width >= 0 && height >= 0) && {
    top: top,
    bottom: bottom,
    left: left,
    right: right,
    width: width,
    height: height
  } || null;
}


/**
 * Shims the native getBoundingClientRect for compatibility with older IE.
 * @param {Element} el The element whose bounding rect to get.
 * @return {DOMRect|ClientRect} The (possibly shimmed) rect of the element.
 */
function getBoundingClientRect(el) {
  var rect;

  try {
    rect = el.getBoundingClientRect();
  } catch (err) {
    // Ignore Windows 7 IE11 "Unspecified error"
    // https://github.com/w3c/IntersectionObserver/pull/205
  }

  if (!rect) return getEmptyRect();

  // Older IE
  if (!(rect.width && rect.height)) {
    rect = {
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom,
      left: rect.left,
      width: rect.right - rect.left,
      height: rect.bottom - rect.top
    };
  }
  return rect;
}


/**
 * Returns an empty rect object. An empty rect is returned when an element
 * is not in the DOM.
 * @return {ClientRect} The empty rect.
 */
function getEmptyRect() {
  return {
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    width: 0,
    height: 0
  };
}


/**
 * Ensure that the result has all of the necessary fields of the DOMRect.
 * Specifically this ensures that `x` and `y` fields are set.
 *
 * @param {?DOMRect|?ClientRect} rect
 * @return {?DOMRect}
 */
function ensureDOMRect(rect) {
  // A `DOMRect` object has `x` and `y` fields.
  if (!rect || 'x' in rect) {
    return rect;
  }
  // A IE's `ClientRect` type does not have `x` and `y`. The same is the case
  // for internally calculated Rect objects. For the purposes of
  // `IntersectionObserver`, it's sufficient to simply mirror `left` and `top`
  // for these fields.
  return {
    top: rect.top,
    y: rect.top,
    bottom: rect.bottom,
    left: rect.left,
    x: rect.left,
    right: rect.right,
    width: rect.width,
    height: rect.height
  };
}


/**
 * Inverts the intersection and bounding rect from the parent (frame) BCR to
 * the local BCR space.
 * @param {DOMRect|ClientRect} parentBoundingRect The parent's bound client rect.
 * @param {DOMRect|ClientRect} parentIntersectionRect The parent's own intersection rect.
 * @return {ClientRect} The local root bounding rect for the parent's children.
 */
function convertFromParentRect(parentBoundingRect, parentIntersectionRect) {
  var top = parentIntersectionRect.top - parentBoundingRect.top;
  var left = parentIntersectionRect.left - parentBoundingRect.left;
  return {
    top: top,
    left: left,
    height: parentIntersectionRect.height,
    width: parentIntersectionRect.width,
    bottom: top + parentIntersectionRect.height,
    right: left + parentIntersectionRect.width
  };
}


/**
 * Checks to see if a parent element contains a child element (including inside
 * shadow DOM).
 * @param {Node} parent The parent element.
 * @param {Node} child The child element.
 * @return {boolean} True if the parent node contains the child node.
 */
function containsDeep(parent, child) {
  var node = child;
  while (node) {
    if (node == parent) return true;

    node = getParentNode(node);
  }
  return false;
}


/**
 * Gets the parent node of an element or its host element if the parent node
 * is a shadow root.
 * @param {Node} node The node whose parent to get.
 * @return {Node|null} The parent node or null if no parent exists.
 */
function getParentNode(node) {
  var parent = node.parentNode;

  if (node.nodeType == /* DOCUMENT */ 9 && node != document) {
    // If this node is a document node, look for the embedding frame.
    return getFrameElement(node);
  }

  if (parent && parent.nodeType == 11 && parent.host) {
    // If the parent is a shadow root, return the host element.
    return parent.host;
  }

  if (parent && parent.assignedSlot) {
    // If the parent is distributed in a <slot>, return the parent of a slot.
    return parent.assignedSlot.parentNode;
  }

  return parent;
}


// Exposes the constructors globally.
window.IntersectionObserver = IntersectionObserver;
window.IntersectionObserverEntry = IntersectionObserverEntry;

}());

},{}],"vL5c":[function(require,module,exports) {
var define;
var global = arguments[3];
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
	typeof define === 'function' && define.amd ? define(factory) :
	(global.scrollama = factory());
}(this, (function () { 'use strict';

// DOM helper functions

// public
function selectAll(selector, parent) {
  if ( parent === void 0 ) parent = document;

  if (typeof selector === 'string') {
    return Array.from(parent.querySelectorAll(selector));
  } else if (selector instanceof Element) {
    return [selector];
  } else if (selector instanceof NodeList) {
    return Array.from(selector);
  } else if (selector instanceof Array) {
    return selector;
  }
  return [];
}

function getOffsetId(id) {
  return ("scrollama__debug-offset--" + id);
}

// SETUP
function setupOffset(ref) {
  var id = ref.id;
  var offsetVal = ref.offsetVal;
  var stepClass = ref.stepClass;

  var el = document.createElement("div");
  el.id = getOffsetId(id);
  el.className = "scrollama__debug-offset";
  el.style.position = "fixed";
  el.style.left = "0";
  el.style.width = "100%";
  el.style.height = "0";
  el.style.borderTop = "2px dashed black";
  el.style.zIndex = "9999";

  var p = document.createElement("p");
  p.innerHTML = "\"." + stepClass + "\" trigger: <span>" + offsetVal + "</span>";
  p.style.fontSize = "12px";
  p.style.fontFamily = "monospace";
  p.style.color = "black";
  p.style.margin = "0";
  p.style.padding = "6px";
  el.appendChild(p);
  document.body.appendChild(el);
}

function setup(ref) {
  var id = ref.id;
  var offsetVal = ref.offsetVal;
  var stepEl = ref.stepEl;

  var stepClass = stepEl[0].className;
  setupOffset({ id: id, offsetVal: offsetVal, stepClass: stepClass });
}

// UPDATE
function update(ref) {
  var id = ref.id;
  var offsetMargin = ref.offsetMargin;
  var offsetVal = ref.offsetVal;
  var format = ref.format;

  var post = format === "pixels" ? "px" : "";
  var idVal = getOffsetId(id);
  var el = document.getElementById(idVal);
  el.style.top = offsetMargin + "px";
  el.querySelector("span").innerText = "" + offsetVal + post;
}

function notifyStep(ref) {
  var id = ref.id;
  var index = ref.index;
  var state = ref.state;

  var prefix = "scrollama__debug-step--" + id + "-" + index;
  var elA = document.getElementById((prefix + "_above"));
  var elB = document.getElementById((prefix + "_below"));
  var display = state === "enter" ? "block" : "none";

  if (elA) { elA.style.display = display; }
  if (elB) { elB.style.display = display; }
}

function scrollama() {
  var OBSERVER_NAMES = [
    "stepAbove",
    "stepBelow",
    "stepProgress",
    "viewportAbove",
    "viewportBelow"
  ];

  var cb = {};
  var io = {};

  var id = null;
  var stepEl = [];
  var stepOffsetHeight = [];
  var stepOffsetTop = [];
  var stepStates = [];

  var offsetVal = 0;
  var offsetMargin = 0;
  var viewH = 0;
  var pageH = 0;
  var previousYOffset = 0;
  var progressThreshold = 0;

  var isReady = false;
  var isEnabled = false;
  var isDebug = false;

  var progressMode = false;
  var preserveOrder = false;
  var triggerOnce = false;

  var direction = "down";
  var format = "percent";

  var exclude = [];

  /* HELPERS */
  function err(msg) {
    console.error(("scrollama error: " + msg));
  }

  function reset() {
    cb = {
      stepEnter: function () {},
      stepExit: function () {},
      stepProgress: function () {}
    };
    io = {};
  }

  function generateInstanceID() {
    var a = "abcdefghijklmnopqrstuv";
    var l = a.length;
    var t = Date.now();
    var r = [0, 0, 0].map(function (d) { return a[Math.floor(Math.random() * l)]; }).join("");
    return ("" + r + t);
  }

  function getOffsetTop(el) {
    var ref = el.getBoundingClientRect();
    var top = ref.top;
    var scrollTop = window.pageYOffset;
    var clientTop = document.body.clientTop || 0;
    return top + scrollTop - clientTop;
  }

  function getPageHeight() {
    var body = document.body;
    var html = document.documentElement;

    return Math.max(
      body.scrollHeight,
      body.offsetHeight,
      html.clientHeight,
      html.scrollHeight,
      html.offsetHeight
    );
  }

  function getIndex(element) {
    return +element.getAttribute("data-scrollama-index");
  }

  function updateDirection() {
    if (window.pageYOffset > previousYOffset) { direction = "down"; }
    else if (window.pageYOffset < previousYOffset) { direction = "up"; }
    previousYOffset = window.pageYOffset;
  }

  function disconnectObserver(name) {
    if (io[name]) { io[name].forEach(function (d) { return d.disconnect(); }); }
  }

  function handleResize() {
    viewH = window.innerHeight;
    pageH = getPageHeight();

    var mult = format === "pixels" ? 1 : viewH;
    offsetMargin = offsetVal * mult;

    if (isReady) {
      stepOffsetHeight = stepEl.map(function (el) { return el.getBoundingClientRect().height; });
      stepOffsetTop = stepEl.map(getOffsetTop);
      if (isEnabled) { updateIO(); }
    }

    if (isDebug) { update({ id: id, offsetMargin: offsetMargin, offsetVal: offsetVal, format: format }); }
  }

  function handleEnable(enable) {
    if (enable && !isEnabled) {
      // enable a disabled scroller
      if (isReady) {
        // enable a ready scroller
        updateIO();
      } else {
        // can't enable an unready scroller
        err("scrollama error: enable() called before scroller was ready");
        isEnabled = false;
        return; // all is not well, don't set the requested state
      }
    }
    if (!enable && isEnabled) {
      // disable an enabled scroller
      OBSERVER_NAMES.forEach(disconnectObserver);
    }
    isEnabled = enable; // all is well, set requested state
  }

  function createThreshold(height) {
    var count = Math.ceil(height / progressThreshold);
    var t = [];
    var ratio = 1 / count;
    for (var i = 0; i < count; i += 1) {
      t.push(i * ratio);
    }
    return t;
  }

  /* NOTIFY CALLBACKS */
  function notifyStepProgress(element, progress) {
    var index = getIndex(element);
    if (progress !== undefined) { stepStates[index].progress = progress; }
    var resp = { element: element, index: index, progress: stepStates[index].progress };

    if (stepStates[index].state === "enter") { cb.stepProgress(resp); }
  }

  function notifyOthers(index, location) {
    if (location === "above") {
      // check if steps above/below were skipped and should be notified first
      for (var i = 0; i < index; i += 1) {
        var ss = stepStates[i];
        if (ss.state !== "enter" && ss.direction !== "down") {
          notifyStepEnter(stepEl[i], "down", false);
          notifyStepExit(stepEl[i], "down");
        } else if (ss.state === "enter") { notifyStepExit(stepEl[i], "down"); }
        // else if (ss.direction === 'up') {
        //   notifyStepEnter(stepEl[i], 'down', false);
        //   notifyStepExit(stepEl[i], 'down');
        // }
      }
    } else if (location === "below") {
      for (var i$1 = stepStates.length - 1; i$1 > index; i$1 -= 1) {
        var ss$1 = stepStates[i$1];
        if (ss$1.state === "enter") {
          notifyStepExit(stepEl[i$1], "up");
        }
        if (ss$1.direction === "down") {
          notifyStepEnter(stepEl[i$1], "up", false);
          notifyStepExit(stepEl[i$1], "up");
        }
      }
    }
  }

  function notifyStepEnter(element, dir, check) {
    if ( check === void 0 ) check = true;

    var index = getIndex(element);
    var resp = { element: element, index: index, direction: dir };

    // store most recent trigger
    stepStates[index].direction = dir;
    stepStates[index].state = "enter";
    if (preserveOrder && check && dir === "down") { notifyOthers(index, "above"); }

    if (preserveOrder && check && dir === "up") { notifyOthers(index, "below"); }

    if (cb.stepEnter && !exclude[index]) {
      cb.stepEnter(resp, stepStates);
      if (isDebug) { notifyStep({ id: id, index: index, state: "enter" }); }
      if (triggerOnce) { exclude[index] = true; }
    }

    if (progressMode) { notifyStepProgress(element); }
  }

  function notifyStepExit(element, dir) {
    var index = getIndex(element);
    var resp = { element: element, index: index, direction: dir };

    if (progressMode) {
      if (dir === "down" && stepStates[index].progress < 1)
        { notifyStepProgress(element, 1); }
      else if (dir === "up" && stepStates[index].progress > 0)
        { notifyStepProgress(element, 0); }
    }

    // store most recent trigger
    stepStates[index].direction = dir;
    stepStates[index].state = "exit";

    cb.stepExit(resp, stepStates);
    if (isDebug) { notifyStep({ id: id, index: index, state: "exit" }); }
  }

  /* OBSERVER - INTERSECT HANDLING */
  // this is good for entering while scrolling down + leaving while scrolling up
  function intersectStepAbove(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var boundingClientRect = entry.boundingClientRect;
    var target = entry.target;

    // bottom = bottom edge of element from top of viewport
    // bottomAdjusted = bottom edge of element from trigger
    var top = boundingClientRect.top;
    var bottom = boundingClientRect.bottom;
    var topAdjusted = top - offsetMargin;
    var bottomAdjusted = bottom - offsetMargin;
    var index = getIndex(target);
    var ss = stepStates[index];

    // entering above is only when topAdjusted is negative
    // and bottomAdjusted is positive
    if (
      isIntersecting &&
      topAdjusted <= 0 &&
      bottomAdjusted >= 0 &&
      direction === "down" &&
      ss.state !== "enter"
    )
      { notifyStepEnter(target, direction); }

    // exiting from above is when topAdjusted is positive and not intersecting
    if (
      !isIntersecting &&
      topAdjusted > 0 &&
      direction === "up" &&
      ss.state === "enter"
    )
      { notifyStepExit(target, direction); }
  }

  // this is good for entering while scrolling up + leaving while scrolling down
  function intersectStepBelow(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var boundingClientRect = entry.boundingClientRect;
    var target = entry.target;

    // bottom = bottom edge of element from top of viewport
    // bottomAdjusted = bottom edge of element from trigger
    var top = boundingClientRect.top;
    var bottom = boundingClientRect.bottom;
    var topAdjusted = top - offsetMargin;
    var bottomAdjusted = bottom - offsetMargin;
    var index = getIndex(target);
    var ss = stepStates[index];

    // entering below is only when bottomAdjusted is positive
    // and topAdjusted is negative
    if (
      isIntersecting &&
      topAdjusted <= 0 &&
      bottomAdjusted >= 0 &&
      direction === "up" &&
      ss.state !== "enter"
    )
      { notifyStepEnter(target, direction); }

    // exiting from above is when bottomAdjusted is negative and not intersecting
    if (
      !isIntersecting &&
      bottomAdjusted < 0 &&
      direction === "down" &&
      ss.state === "enter"
    )
      { notifyStepExit(target, direction); }
  }

  /*
	if there is a scroll event where a step never intersects (therefore
	skipping an enter/exit trigger), use this fallback to detect if it is
	in view
	*/
  function intersectViewportAbove(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var target = entry.target;
    var index = getIndex(target);
    var ss = stepStates[index];

    if (
      isIntersecting &&
      direction === "down" &&
      ss.direction !== "down" &&
      ss.state !== "enter"
    ) {
      notifyStepEnter(target, "down");
      notifyStepExit(target, "down");
    }
  }

  function intersectViewportBelow(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var target = entry.target;
    var index = getIndex(target);
    var ss = stepStates[index];
    if (
      isIntersecting &&
      direction === "up" &&
      ss.direction === "down" &&
      ss.state !== "enter"
    ) {
      notifyStepEnter(target, "up");
      notifyStepExit(target, "up");
    }
  }

  function intersectStepProgress(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var intersectionRatio = entry.intersectionRatio;
    var boundingClientRect = entry.boundingClientRect;
    var target = entry.target;
    var bottom = boundingClientRect.bottom;
    var bottomAdjusted = bottom - offsetMargin;
    if (isIntersecting && bottomAdjusted >= 0) {
      notifyStepProgress(target, +intersectionRatio);
    }
  }

  /*  OBSERVER - CREATION */
  // jump into viewport
  function updateViewportAboveIO() {
    io.viewportAbove = stepEl.map(function (el, i) {
      var marginTop = pageH - stepOffsetTop[i];
      var marginBottom = offsetMargin - viewH - stepOffsetHeight[i];
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectViewportAbove, options);
      obs.observe(el);
      return obs;
    });
  }

  function updateViewportBelowIO() {
    io.viewportBelow = stepEl.map(function (el, i) {
      var marginTop = -offsetMargin - stepOffsetHeight[i];
      var marginBottom = offsetMargin - viewH + stepOffsetHeight[i] + pageH;
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectViewportBelow, options);
      obs.observe(el);
      return obs;
    });
  }

  // look above for intersection
  function updateStepAboveIO() {
    io.stepAbove = stepEl.map(function (el, i) {
      var marginTop = -offsetMargin + stepOffsetHeight[i];
      var marginBottom = offsetMargin - viewH;
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectStepAbove, options);
      obs.observe(el);
      return obs;
    });
  }

  // look below for intersection
  function updateStepBelowIO() {
    io.stepBelow = stepEl.map(function (el, i) {
      var marginTop = -offsetMargin;
      var marginBottom = offsetMargin - viewH + stepOffsetHeight[i];
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectStepBelow, options);
      obs.observe(el);
      return obs;
    });
  }

  // progress progress tracker
  function updateStepProgressIO() {
    io.stepProgress = stepEl.map(function (el, i) {
      var marginTop = stepOffsetHeight[i] - offsetMargin;
      var marginBottom = -viewH + offsetMargin;
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var threshold = createThreshold(stepOffsetHeight[i]);
      var options = { rootMargin: rootMargin, threshold: threshold };
      // console.log(options);
      var obs = new IntersectionObserver(intersectStepProgress, options);
      obs.observe(el);
      return obs;
    });
  }

  function updateIO() {
    OBSERVER_NAMES.forEach(disconnectObserver);

    updateViewportAboveIO();
    updateViewportBelowIO();
    updateStepAboveIO();
    updateStepBelowIO();

    if (progressMode) { updateStepProgressIO(); }
  }

  /* SETUP FUNCTIONS */

  function indexSteps() {
    stepEl.forEach(function (el, i) { return el.setAttribute("data-scrollama-index", i); });
  }

  function setupStates() {
    stepStates = stepEl.map(function () { return ({
      direction: null,
      state: null,
      progress: 0
    }); });
  }

  function addDebug() {
    if (isDebug) { setup({ id: id, stepEl: stepEl, offsetVal: offsetVal }); }
  }

  function isYScrollable(element) {
    var style = window.getComputedStyle(element);
    return (
      (style.overflowY === "scroll" || style.overflowY === "auto") &&
      element.scrollHeight > element.clientHeight
    );
  }

  // recursively search the DOM for a parent container with overflowY: scroll and fixed height
  // ends at document
  function anyScrollableParent(element) {
    if (element && element.nodeType === 1) {
      // check dom elements only, stop at document
      // if a scrollable element is found return the element
      // if not continue to next parent
      return isYScrollable(element)
        ? element
        : anyScrollableParent(element.parentNode);
    }
    return false; // didn't find a scrollable parent
  }

  var S = {};

  S.setup = function (ref) {
    var step = ref.step;
    var offset = ref.offset; if ( offset === void 0 ) offset = 0.5;
    var progress = ref.progress; if ( progress === void 0 ) progress = false;
    var threshold = ref.threshold; if ( threshold === void 0 ) threshold = 4;
    var debug = ref.debug; if ( debug === void 0 ) debug = false;
    var order = ref.order; if ( order === void 0 ) order = true;
    var once = ref.once; if ( once === void 0 ) once = false;

    reset();
    // create id unique to this scrollama instance
    id = generateInstanceID();

    stepEl = selectAll(step);

    if (!stepEl.length) {
      err("no step elements");
      return S;
    }

    // ensure that no step has a scrollable parent element in the dom tree
    // check current step for scrollable parent
    // assume no scrollable parents to start
    var scrollableParent = stepEl.reduce(
      function (foundScrollable, s) { return foundScrollable || anyScrollableParent(s.parentNode); },
      false
    );
    if (scrollableParent) {
      console.error(
        "scrollama error: step elements cannot be children of a scrollable element. Remove any css on the parent element with overflow: scroll; or overflow: auto; on elements with fixed height.",
        scrollableParent
      );
    }

    // options
    isDebug = debug;
    progressMode = progress;
    preserveOrder = order;
    triggerOnce = once;

    S.offsetTrigger(offset);
    progressThreshold = Math.max(1, +threshold);

    isReady = true;

    // customize
    addDebug();
    indexSteps();
    setupStates();
    handleResize();
    S.enable();
    return S;
  };

  S.resize = function () {
    handleResize();
    return S;
  };

  S.enable = function () {
    handleEnable(true);
    return S;
  };

  S.disable = function () {
    handleEnable(false);
    return S;
  };

  S.destroy = function () {
    handleEnable(false);
    reset();
  };

  S.offsetTrigger = function (x) {
    if (x === null) { return offsetVal; }

    if (typeof x === "number") {
      format = "percent";
      if (x > 1) { err("offset value is greater than 1. Fallback to 1."); }
      if (x < 0) { err("offset value is lower than 0. Fallback to 0."); }
      offsetVal = Math.min(Math.max(0, x), 1);
    } else if (typeof x === "string" && x.indexOf("px") > 0) {
      var v = +x.replace("px", "");
      if (!isNaN(v)) {
        format = "pixels";
        offsetVal = v;
      } else {
        err("offset value must be in 'px' format. Fallback to 0.5.");
        offsetVal = 0.5;
      }
    } else {
      err("offset value does not include 'px'. Fallback to 0.5.");
      offsetVal = 0.5;
    }
    return S;
  };

  S.onStepEnter = function (f) {
    if (typeof f === "function") { cb.stepEnter = f; }
    else { err("onStepEnter requires a function"); }
    return S;
  };

  S.onStepExit = function (f) {
    if (typeof f === "function") { cb.stepExit = f; }
    else { err("onStepExit requires a function"); }
    return S;
  };

  S.onStepProgress = function (f) {
    if (typeof f === "function") { cb.stepProgress = f; }
    else { err("onStepProgress requires a function"); }
    return S;
  };

  return S;
}

return scrollama;

})));

},{}],"Na4G":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = findUnique;

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

/**
 * Finds unique values in an array of values
 * @param {array} arr - sequence of strings, numbers, booleans
 * @returns {array} array of unique values
 *
 * @example
 * import findUnique from './utils/unique';
 * const unique = findUnique([1,2,2,3]);
 * // [1,2,3]
 */
function findUnique(arr) {
  return _toConsumableArray(new Set(arr));
}
},{}],"drU0":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\">\n<path d=\"M0 4v24h32v-24h-32zM6 26h-4v-4h4v4zM6 18h-4v-4h4v4zM6 10h-4v-4h4v4zM24 26h-16v-20h16v20zM30 26h-4v-4h4v4zM30 18h-4v-4h4v4zM30 10h-4v-4h4v4zM12 10v12l8-6z\"></path>\n</svg>";
exports.default = _default;
},{}],"modal.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var $body = d3.select('body');
var $modal = d3.select('[data-js="modal"]');
var $info = $modal.select('.modal__info');
var $videos = $modal.select('.modal__video');
var v = Date.now();
var clearCache = "?version=".concat(v);

function setupA11y() {
  // when modal is open, tabbing remains within modal
  var $focusableInModal = $modal.selectAll('.modal__quit, a, img').nodes();
  var $firstFocus = $focusableInModal[0];
  var $lastFocus = $focusableInModal[$focusableInModal.length - 1];
  $firstFocus.focus();
  d3.select($firstFocus).on('keydown', function () {
    var open = !$modal.classed('is-hidden');

    if (open) {
      var pressed = d3.event.code;
      var shift = d3.event.shiftKey;

      if (pressed === 'Tab' && shift === true) {
        // prevent default behavior
        d3.event.preventDefault(); // focus on the last element

        $lastFocus.focus();
      }
    }
  });
  d3.select($lastFocus).on('keydown', function () {
    var open = !$modal.classed('is-hidden');

    if (open) {
      var pressed = d3.event.code;
      var shift = d3.event.shiftKey;

      if (pressed === 'Tab' && shift === false) {
        // prevent default behavior
        d3.event.preventDefault(); // focus on the last element

        $firstFocus.focus();
      }
    }
  });
  $modal.on('keydown', function () {
    var pressed = d3.event.code;
    var open = !$modal.classed('is-hidden');

    if (pressed === 'Escape' && open === true) {
      // close menu 
      close();
    }
  });
  d3.select($firstFocus).on('keydown', function () {
    var pressed = d3.event.code;

    if (pressed === 'Enter') {
      close();
    }
  });
}

function setup(islandData, linkData, animal, facility, id) {
  $modal.classed('is-hidden', false);
  var theseData = linkData.filter(function (d) {
    return d.id === id;
  })[0];
  var animalTitle = theseData.specific ? theseData.specific : animal;
  $info.select('.modal__info-animal').text(animalTitle);
  $info.select('.modal__info-facility').text(facility);
  $info.select('.modal__info-full').text(theseData.camOn === true ? "Go to the full live stream" : "Go to the full live stream (camera may be currently offline)").attr('href', theseData.link).attr('target', '_blank');
  $info.select('.modal__info-help');
  $modal.select('.facility').text(facility);
  $modal.select('.donate').attr('href', theseData.donate);

  if (theseData.adopt) {
    $modal.select('.adopt').attr('href', theseData.adopt).attr('target', '_blank').classed('is-hidden', false);
  } else $modal.select('.adopt').classed('is-hidden', true);

  var $fact = $modal.select('.modal__info-fact');

  if (theseData.fact) {
    $fact.classed('is-hidden', false);
    $fact.select('.facility').text(facility);
    $fact.select('.fact__text').text(theseData.fact);
    $fact.select('.fact__link').attr('href', theseData.learn).attr('target', '_blank');
  } else $fact.classed('is-hidden', true);

  var otherVids = islandData.filter(function (d) {
    return d.animal === animal;
  })[0].camera.filter(function (d) {
    return +d !== +theseData.id;
  });
  $videos.select('.large').attr('tabindex', 0).attr('src', "https://pudding.cool/2020/11/zoo-data/output/".concat(theseData.id, ".gif").concat(clearCache)).attr('alt', function (d) {
    return "Image of ".concat(animal, " at ").concat(facility);
  });
  var $carousel = $videos.select('.modal__video--carousel');

  if (otherVids.length > 0) {
    $carousel.classed('is-hidden', false); // for labelling other vids 

    var crosswalk = linkData.map(function (d) {
      return [+d.id, d.facility];
    });
    var idMap = new Map(crosswalk);
    var $vidCar = $carousel.selectAll('.g-carousel').data(otherVids, function (d) {
      return +d;
    }).join(function (enter) {
      var $container = enter.append('div').attr('class', 'g-carousel');
      $container.append('img').attr('class', 'carousel__display').attr('tabindex', 0).attr('alt', function (d) {
        return "Image of ".concat(animal, " at ").concat(idMap.get(+d));
      }).on('click', function (d, i, n) {
        d3.event.stopPropagation();
        var $sel = d3.select(n[i]);
        var id = $sel.attr('data-id');
        var newFacility = idMap.get(+id);
        setup(islandData, linkData, animal, newFacility, id);
      });
      $container.append('span').attr('class', 'carousel__facility');
      return $container;
    });
    $vidCar.selectAll('.carousel__facility').text(function (d) {
      return idMap.get(+d);
    });
    $vidCar.selectAll('img').attr('data-id', function (d) {
      return d;
    }).attr('src', function (d) {
      return "https://pudding.cool/2020/11/zoo-data/stills/".concat(+d, ".png").concat(clearCache);
    });
  } else $carousel.classed('is-hidden', true);

  setupA11y();
}

function close() {
  $modal.classed('is-hidden', true);
  $body.classed('modal__open', false);
}

$modal.on('click', close);
var _default = {
  setup: setup,
  close: close
};
exports.default = _default;
},{}],"CAFt":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

var $globes = d3.selectAll('.globe');
var $svg = $globes.selectAll('svg');
var $g = null;
var projection = d3.geoOrthographic();
var path = d3.geoPath(projection); //.projection(projection);

var TILT = 5;
var OUTLINE = {
  type: 'Sphere'
};
var DURATION = 1000;
var $map = null;
var geo = null;
var markerData = null;
var p1 = [0, 0];
var p2 = [0, 0];
var r1 = [52.3, -84, 0];
var r2 = [52.3, -84, 0]; // rotate map functions

function interpolateLinear(_ref, _ref2) {
  var _ref3 = _slicedToArray(_ref, 4),
      a1 = _ref3[0],
      b1 = _ref3[1],
      c1 = _ref3[2],
      d1 = _ref3[3];

  var _ref4 = _slicedToArray(_ref2, 4),
      a2 = _ref4[0],
      b2 = _ref4[1],
      c2 = _ref4[2],
      d2 = _ref4[3];

  a2 -= a1, b2 -= b1, c2 -= c1, d2 -= d1;
  var x = new Array(4);
  return function (t) {
    var l = Math.hypot(x[0] = a1 + a2 * t, x[1] = b1 + b2 * t, x[2] = c1 + c2 * t, x[3] = d1 + d2 * t);
    x[0] /= l, x[1] /= l, x[2] /= l, x[3] /= l;
    return x;
  };
}

function interpolate(_ref5, _ref6) {
  var _ref7 = _slicedToArray(_ref5, 4),
      a1 = _ref7[0],
      b1 = _ref7[1],
      c1 = _ref7[2],
      d1 = _ref7[3];

  var _ref8 = _slicedToArray(_ref6, 4),
      a2 = _ref8[0],
      b2 = _ref8[1],
      c2 = _ref8[2],
      d2 = _ref8[3];

  var dot = a1 * a2 + b1 * b2 + c1 * c2 + d1 * d2;
  if (dot < 0) a2 = -a2, b2 = -b2, c2 = -c2, d2 = -d2, dot = -dot;

  if (dot > 0.9995) {
    return interpolateLinear([a1, b1, c1, d1], [a2, b2, c2, d2]);
  }

  var theta0 = Math.acos(Math.max(-1, Math.min(1, dot)));
  var x = new Array(4);
  var l = Math.hypot(a2 -= a1 * dot, b2 -= b1 * dot, c2 -= c1 * dot, d2 -= d1 * dot);
  a2 /= l, b2 /= l, c2 /= l, d2 /= l;
  return function (t) {
    var theta = theta0 * t;
    var s = Math.sin(theta);
    var c = Math.cos(theta);
    x[0] = a1 * c + a2 * s;
    x[1] = b1 * c + b2 * s;
    x[2] = c1 * c + c2 * s;
    x[3] = d1 * c + d2 * s;
    return x;
  };
}

function fromAngles(_ref9) {
  var _ref10 = _slicedToArray(_ref9, 3),
      l = _ref10[0],
      p = _ref10[1],
      g = _ref10[2];

  l *= Math.PI / 360;
  p *= Math.PI / 360;
  g *= Math.PI / 360;
  var sl = Math.sin(l);
  var cl = Math.cos(l);
  var sp = Math.sin(p);
  var cp = Math.cos(p);
  var sg = Math.sin(g);
  var cg = Math.cos(g);
  return [cl * cp * cg + sl * sp * sg, sl * cp * cg - cl * sp * sg, cl * sp * cg + sl * cp * sg, cl * cp * sg - sl * sp * cg];
}

function toAngles(_ref11) {
  var _ref12 = _slicedToArray(_ref11, 4),
      a = _ref12[0],
      b = _ref12[1],
      c = _ref12[2],
      d = _ref12[3];

  return [Math.atan2(2 * (a * b + c * d), 1 - 2 * (b * b + c * c)) * 180 / Math.PI, Math.asin(Math.max(-1, Math.min(1, 2 * (a * c - d * b)))) * 180 / Math.PI, Math.atan2(2 * (a * d + b * c), 1 - 2 * (c * c + d * d)) * 180 / Math.PI];
}

function interpolateAngles(a, b) {
  var i = interpolate(fromAngles(a), fromAngles(b));
  return function (t) {
    return toAngles(i(t));
  };
}

function update(lat, long) {
  if (geo) {
    var matched = geo.features.filter(function (e) {
      return e.properties.iso_a2 === 'CA';
    })[0];
    var matched2 = geo.features.filter(function (e) {
      return e.properties.iso_a2 === 'US';
    })[0];
    var manual = projection([long, lat]);
    var manualInv = projection.invert(manual);
    var cent = d3.geoCentroid(matched);
    var centInv = projection.invert(cent);
    p1 = p2;
    p2 = [long, lat];
    r1 = r2;
    r2 = [-p2[0], TILT - p2[1], 0];
    var iv = interpolateAngles(r1, r2);
    var countryPaths = $map.selectAll('.path-country');
    d3.transition().duration(DURATION).tween('render', function () {
      return function (t) {
        projection.rotate(iv(t));
        countryPaths.attr('d', path);
      };
    });
  }
}

function addLabels() {
  // add path for text
  $g.append('path').attr('id', 'globe--top').attr('d', 'M-4,50 A 54,54 0 0,1 104,50').style('fill', 'none').style('stroke', 'none'); // $g.append('text')
  //   .append('textPath')
  //   .attr('xlink:href', '#globe--top')
  //   .style('text-anchor', 'middle')
  //   .attr('startOffset', '50%')
  //   .text('Geographic Center')
  //   .attr('font-size', '14px')

  $g.append('path').attr('id', 'globe--bottom').attr('d', 'M-12,50 A 62,62 0 0,0 112,50').style('fill', 'none').style('stroke', 'none');
  $g.append('text').append('textPath').attr('xlink:href', '#globe--bottom').style('text-anchor', 'middle').style('text-baseline', 'hanging').attr('startOffset', '50%').text('Center of Wild Range').attr('font-size', '14px');
}

function drawMarkers(markers) {
  var circles = $svg.selectAll('.marker').data(markers).join(function (enter) {
    return enter.append('circle').attr('class', 'marker').attr('r', 15);
  });
}

function resize() {//$svg.selectAll('.g-map').attr('transform', 'translate(50px, 50px)')
}

function setupMap(geojson) {
  $g = $svg.append('g').attr('class', 'g-globe');
  $g.style('transform', 'translate(15px, 15px)'); // setup map group

  $map = $g.append('g').attr('class', 'g-map');
  $map.append('path').attr('class', 'path-sphere');
  $map.append('g').attr('class', 'g-countries');
  var width = 100;
  var height = 100; // draw map

  projection.fitSize([width, height], geojson).center([0, 0]).rotate([52.3, -84, 0]); // size globe border

  $map.select('.path-sphere').attr('d', path(OUTLINE)) // .style('fill', 'white')
  // .style('stroke-width', '1px')
  .lower();
  var countryPaths = $map.select('.g-countries').selectAll('.path-country').data(geojson.features).join(function (enter) {
    return enter.append('path').attr('class', function (d) {
      return "path-country country-".concat(d.properties.iso_a2);
    });
  });
  countryPaths.attr('d', path);
  geo = geojson;
  addLabels();
}

function init(markers) {
  markerData = markers;
  (0, _loadData.default)('custom2.geojson').then(function (result) {
    return setupMap(result);
  }); //.then(() => drawMarkers(markers))
}

var _default = {
  init: init,
  update: update,
  resize: resize
};
exports.default = _default;
},{"./load-data":"xZJw"}],"g1DG":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/**
 * @this {Promise}
 */
function finallyConstructor(callback) {
  var constructor = this.constructor;
  return this.then(function (value) {
    // @ts-ignore
    return constructor.resolve(callback()).then(function () {
      return value;
    });
  }, function (reason) {
    // @ts-ignore
    return constructor.resolve(callback()).then(function () {
      // @ts-ignore
      return constructor.reject(reason);
    });
  });
}

var _default = finallyConstructor;
exports.default = _default;
},{}],"gqUM":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _finally = _interopRequireDefault(require("./finally"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Store setTimeout reference so promise-polyfill will be unaffected by
// other code modifying setTimeout (like sinon.useFakeTimers())
var setTimeoutFunc = setTimeout;

function isArray(x) {
  return Boolean(x && typeof x.length !== 'undefined');
}

function noop() {} // Polyfill for Function.prototype.bind


function bind(fn, thisArg) {
  return function () {
    fn.apply(thisArg, arguments);
  };
}
/**
 * @constructor
 * @param {Function} fn
 */


function Promise(fn) {
  if (!(this instanceof Promise)) throw new TypeError('Promises must be constructed via new');
  if (typeof fn !== 'function') throw new TypeError('not a function');
  /** @type {!number} */

  this._state = 0;
  /** @type {!boolean} */

  this._handled = false;
  /** @type {Promise|undefined} */

  this._value = undefined;
  /** @type {!Array<!Function>} */

  this._deferreds = [];
  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }

  if (self._state === 0) {
    self._deferreds.push(deferred);

    return;
  }

  self._handled = true;

  Promise._immediateFn(function () {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;

    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }

    var ret;

    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }

    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self) throw new TypeError('A promise cannot be resolved with itself.');

    if (newValue && (typeof newValue === 'object' || typeof newValue === 'function')) {
      var then = newValue.then;

      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === 'function') {
        doResolve(bind(then, newValue), self);
        return;
      }
    }

    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function () {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }

  self._deferreds = null;
}
/**
 * @constructor
 */


function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : null;
  this.onRejected = typeof onRejected === 'function' ? onRejected : null;
  this.promise = promise;
}
/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */


function doResolve(fn, self) {
  var done = false;

  try {
    fn(function (value) {
      if (done) return;
      done = true;
      resolve(self, value);
    }, function (reason) {
      if (done) return;
      done = true;
      reject(self, reason);
    });
  } catch (ex) {
    if (done) return;
    done = true;
    reject(self, ex);
  }
}

Promise.prototype['catch'] = function (onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function (onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);
  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype['finally'] = _finally.default;

Promise.all = function (arr) {
  return new Promise(function (resolve, reject) {
    if (!isArray(arr)) {
      return reject(new TypeError('Promise.all accepts an array'));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === 'object' || typeof val === 'function')) {
          var then = val.then;

          if (typeof then === 'function') {
            then.call(val, function (val) {
              res(i, val);
            }, reject);
            return;
          }
        }

        args[i] = val;

        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function (value) {
  if (value && typeof value === 'object' && value.constructor === Promise) {
    return value;
  }

  return new Promise(function (resolve) {
    resolve(value);
  });
};

Promise.reject = function (value) {
  return new Promise(function (resolve, reject) {
    reject(value);
  });
};

Promise.race = function (arr) {
  return new Promise(function (resolve, reject) {
    if (!isArray(arr)) {
      return reject(new TypeError('Promise.race accepts an array'));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
}; // Use polyfill for setImmediate for performance gains


Promise._immediateFn = // @ts-ignore
typeof setImmediate === 'function' && function (fn) {
  // @ts-ignore
  setImmediate(fn);
} || function (fn) {
  setTimeoutFunc(fn, 0);
};

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err) {
  if (typeof console !== 'undefined' && console) {
    console.warn('Possible Unhandled Promise Rejection:', err); // eslint-disable-line no-console
  }
};

var _default = Promise;
exports.default = _default;
},{"./finally":"g1DG"}],"arrangement.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _loadData = _interopRequireDefault(require("./load-data"));

var _loadImagePromise = _interopRequireDefault(require("./utils/load-image-promise"));

require("intersection-observer");

var _scrollama = _interopRequireDefault(require("scrollama"));

var _unique = _interopRequireDefault(require("./utils/unique"));

var _videoSVG = _interopRequireDefault(require("./videoSVG"));

var _modal = _interopRequireDefault(require("./modal"));

var _globe = _interopRequireDefault(require("./globe"));

var _promisePolyfill = require("promise-polyfill");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var $body = d3.select('body');
var $section = $body.selectAll('[data-js="arrangement"]');
var $islands = $section.selectAll('[data-js="arrangement__islands"]');
var $mobileNav = d3.selectAll('[data-js="navigation"]');
var $mobileAnimals = $mobileNav.select('.animal');
var $update = d3.select('.update');
var heights = [];
var v = Date.now();
var clearCache = "?version=".concat(v);
var linkData = null;
var mappedData = null;
var nestedData = null;
var idToFacilityMap = null;
var TOTAL_ISLANDS = 16;
var HOLE_OFFSET = 100;
var BREAKPOINT = 848;
var MOBILE = false;
var MOBILE_SETUP = false;
var DESKTOP_SETUP = false;
var EXHIBIT_WIDTH = 1228;
var MAX_ISLAND_WIDTH = 1200;
var TOP_GAP = {
  1: '21.2%',
  2: '16.7%',
  3: '11.7%',
  4: '9.02%',
  5: '7.33%'
};
var MIDDLE_GAP = {
  1: '48.4%',
  2: '18.65%',
  3: '13.1%',
  4: '10.1%',
  5: '8.2%'
};
var scroller = (0, _scrollama.default)();
var habitatScroller = (0, _scrollama.default)();

function swapSource(el) {
  var $sel = d3.select(el); //d3.select(this)

  var id = $sel.attr('data-id');
  var type = $sel.attr('data-type');

  if (type === 'png') {
    $sel.attr('src', "https://pudding.cool/2020/11/zoo-data/output/".concat(id, ".gif").concat(clearCache));
    $sel.attr('data-type', 'gif');
  } else {
    $sel.attr('src', "https://pudding.cool/2020/11/zoo-data/stills/".concat(id, ".png").concat(clearCache));
    $sel.attr('data-type', 'png');
  }
}

var sleep = function sleep(milliseconds) {
  return new Promise(function (resolve) {
    return setTimeout(resolve, milliseconds);
  });
};

function highlightList(element) {
  var all = $section.selectAll('.g-anno');
  all.classed('in-focus', false);
  var animal = d3.select(element).attr('data-animal');
  var $anno = $section.selectAll("[data-list=\"".concat(animal, "\"]")).classed('in-focus', true);
  var $list = $anno.selectAll('li'); //  if ($list.size() > 1){
  //     for (const li in $list){
  //         console.log({li})
  //         sleep(500).then(() => console.log({slept: li}))
  //     }
  //  }
}

function setupHabitatScroll() {
  habitatScroller.setup({
    step: '.g-island',
    offset: 0.8,
    debug: false
  }).onStepEnter(function (response) {
    var element = response.element,
        index = response.index,
        direction = response.direction;
    var $el = d3.select(element);

    if (index === TOTAL_ISLANDS) {
      $section.selectAll('.clouds__base, .globe').classed('is-hidden', false);
    }
  }).onStepExit(function (response) {
    var element = response.element,
        index = response.index,
        direction = response.direction;

    if (index === TOTAL_ISLANDS && direction === 'down') {
      $section.selectAll('.clouds__base, .globe').classed('is-hidden', true); // $globe.classed('is-hidden', true)
    }
  });
}

function setupScroll() {
  scroller.setup({
    step: '.cam__display',
    debug: false
  }).onStepEnter(function (response) {
    var element = response.element,
        index = response.index,
        direction = response.direction;
    var first = index === 0 && direction === 'down'; // stop anything else playing 

    if (first === false) {
      var playing = $islands.select('[data-type="gif"]');

      if (playing.size() > 0) {
        swapSource(playing.node());
        playing.classed('in-focus', false);
      }
    }

    swapSource(element);
    $section.selectAll('.cam__display').classed('in-focus', false);
    var $el = d3.select(element);
    $el.classed('in-focus', true);
    highlightList(element); // update globe 

    var elData = $el.data()[0];
    var lat = elData.lat,
        long = elData.long;

    _globe.default.update(+lat, +long);

    if (MOBILE) {
      $mobileAnimals.selectAll('.g-anno').classed('is-hidden', true);
      var animal = d3.select(element).attr('data-animal');
      var $ul = $mobileAnimals.selectAll('.g-anno').filter(function (d, i, n) {
        return d3.select(n[i]).attr('data-list') === animal;
      }); //.selectAll(`[data-animal="${animal}"]`)

      $ul.classed('is-hidden', false);
      var top = $ul.node().offsetTop;
      var wrapper = $mobileNav.node().scrollTop;
      $mobileNav.node().scrollBy({
        top: top - wrapper,
        left: 0,
        behavior: 'smooth'
      }); // $ul.node().scrollIntoView({
      //     behavior: 'smooth',
      //     block: 'center'
      // })
    }
  }).onStepExit(function (response) {
    var element = response.element,
        index = response.index,
        direction = response.direction;

    if (index === 1 && direction === 'up') {
      // if beluga and scrolling up, re-highlight the polar bear
      var $el = d3.select(element);
      $el.classed('in-focus', false);
      swapSource(element);
      var pb = d3.selectAll('.cam__display').filter(function (d, i, n) {
        return d3.select(n[i]).attr('data-animal') === 'polar bear';
      });
      swapSource(pb.node());
      pb.classed('in-focus', true);
      highlightList(pb.node());
    }
  });
}

function findFirst(arr, facMap) {
  var split = arr.split(', ');
  var facilities = split.map(function (d) {
    return {
      id: d,
      facility: facMap.get(d)
    };
  }).sort(function (a, b) {
    return d3.ascending(a.facility, b.facility);
  });
  var first = facilities[0].id;
  return first;
}

function cleanData(dat, timestamps) {
  return new Promise(function (resolve) {
    var updatedLinks = dat[1].map(function (d) {
      return _objectSpread({}, d, {
        camOn: timestamps.includes(+d.id)
      });
    });
    linkData = updatedLinks;
    idToFacilityMap = new Map(linkData.map(function (d) {
      return [d.id, d.facility];
    }));
    mappedData = dat[0].map(function (d) {
      return _objectSpread({}, d, {
        index: +d.index,
        positionY: +d.positionY,
        camera: d.camera.split(', '),
        first: findFirst(d.camera, idToFacilityMap)
      });
    });
    nestedData = d3.nest().key(function (d) {
      return d.tile;
    }).entries(mappedData); // const uniqueHeights = findUnique(mappedData.map(d => d.imHeight))
    // uniqueHeights.forEach(h => {
    //     heights[h] = findNewHeight(h)
    // })

    resolve({
      mappedData: mappedData,
      nestedData: nestedData,
      links: updatedLinks
    });
  });
}

function launchModal($sel) {
  //const $sel = d3.select(this)
  var animal = $sel.attr('data-animal');
  var group = $section.selectAll("[data-list=\"".concat(animal, "\"]"));
  var selRadio = group.select('fieldset').selectAll('input:checked');
  var id = selRadio.data()[0].id;
  var facility = selRadio.attr('data-facility');
  $body.classed('modal__open', true);

  _modal.default.setup(mappedData, linkData, animal, facility, id);
}

function findGridArea(cam, i) {
  // if on the right, column 2, otherwise 1
  var index = cam.index;
  var row = cam.positionY * 2;
  var column = cam.positionX === 'R' ? 2 : 1;
  if (index % 2 === 0) return "".concat(row, " / ").concat(column + 1, " / span 1 / span 1");else if (index === 1) return "".concat(row, " / ").concat(column + 1, " / span 1 / span 1");else return "".concat(row, " / ").concat(column, " / span 1 / span 1 ");
}

function resize() {
  MOBILE = window.innerWidth < BREAKPOINT || window.innerWidth > window.screen.width;
  var $exhibits = $islands.selectAll('.exhibit');
  $exhibits.nodes().forEach(function (ex) {
    var tile = d3.select(ex).attr('data-tile');
    var h = ex.offsetHeight;
    heights[tile] = h;
  });
  $islands.selectAll('.tile, .annotation--desktop').style('height', function (d) {
    return "".concat(heights[d[0].tile], "px");
  });
  setupNav();
}

function setupFacilities(group) {
  group.selectAll('fieldset').selectAll('.animal--facility').data(function (d) {
    var animal = d.animal;
    var facilities = linkData.filter(function (e) {
      return e.animal === animal;
    }).map(function (e) {
      return _objectSpread({}, e, {
        tile: d.tile,
        positionX: d.positionX
      });
    }).sort(function (a, b) {
      return d3.ascending(a.facility, b.facility);
    });
    return facilities;
  }).join(function (enter) {
    var $wrapper = enter.append('div').attr('class', 'wrapper'); // .html(d => `<span class='facility--name'>${d.facility}</span> `)

    var $radio = $wrapper.append('input').attr('type', 'radio').attr('value', function (d) {
      return d.id;
    }).attr('class', 'animal--facility').attr('id', function (d) {
      return "facility--".concat(d.id);
    }).attr('data-facility', function (d) {
      return d.facility;
    }).attr('data-id', function (d) {
      return d.id;
    }).attr('data-animal', function (d) {
      return d.animal;
    }).attr('data-tile', function (d) {
      return d.tile;
    }).attr('tabindex', function (d, i) {
      return i === 0 ? 0 : -1;
    }).property('checked', function (d) {
      var thisCam = $section.select("[data-exhibit=\"".concat(d.tile, "\"]")).selectAll('.cam__display').filter(function (e, i, n) {
        return d3.select(n[i]).attr('data-animal') === d.animal;
      });
      var displayed = thisCam.attr('data-id');
      return d.id === displayed;
    }).classed('selected', function (d) {
      var thisCam = $section.select("[data-exhibit=\"".concat(d.tile, "\"]")).selectAll('.cam__display').filter(function (e, i, n) {
        return d3.select(n[i]).attr('data-animal') === d.animal;
      });
      var displayed = thisCam.attr('data-id');
      return d.id === displayed ? 'checked' : '';
    }).on('click', switchFacility);
    $radio.select('.video--icon').classed('is-hidden', function (d) {
      var thisCam = $section.select("[data-exhibit=\"".concat(d.tile, "\"]")).selectAll('.cam__display').filter(function (e, i, n) {
        return d3.select(n[i]).attr('data-animal') === d.animal;
      });
      var displayed = thisCam.attr('data-id');
      return d.id !== displayed;
    });
    var $label = $wrapper.append('label').attr('for', function (d) {
      return "facility--".concat(d.id);
    }).text(function (d) {
      return d.facility;
    });
  });
}

function setupNav() {
  var $g = null; // if on mobile and mobile nav isn't already setup

  if (MOBILE === true && MOBILE_SETUP === false) {
    MOBILE_SETUP = true;
    $g = $mobileAnimals.selectAll('.g-anno').data(mappedData).join(function (enter) {
      var $container = enter.append('div').attr('class', 'g-anno').attr('data-list', function (d) {
        return d.animal;
      }) // .style('transform', d => {
      //     const val = d.positionX === 'L' ? 0 : '60%'
      //     return `translateX(${val})`
      // })
      // .style('left', d => d.positionX === 'L' ? 0 : '40%')
      .style('align-self', function (d) {
        return d.positionX === 'L' ? 'flex-start' : 'flex-end';
      });
      $container.append('h3').attr('class', 'animal--name').text(function (d) {
        return d.animal;
      }).attr('data-animal', function (d) {
        return d.animal;
      }).attr('data-id', function (d) {
        return d.id;
      }).style('text-align', function (d) {
        return d.positionX === 'L' ? 'left' : 'right';
      }).on('click', function (d, i, n) {
        return launchModal(d3.select(n[i]));
      });
      var $fs = $container.append('fieldset').attr('class', 'animal--list').attr('data-animal', function (d) {
        return d.animal;
      }).attr('tabindex', 0);
      $fs.append('legend').text(function (d) {
        return "Facilities with a ".concat(d.animal, " live stream");
      }).attr('class', 'sr-only');
      return $container;
    });
    setupFacilities($g);
  } else if (MOBILE === false && DESKTOP_SETUP === false) {
    DESKTOP_SETUP = true; // add annotations for desktop

    var $annoD = $islands.selectAll('.g-island').selectAll('.annotation--desktop').data(function (d) {
      return [d.values];
    }).join(function (enter) {
      return enter.append('div').attr('class', 'annotation--desktop');
    }).style('grid-template-rows', function (d) {
      return determineGridRows(d);
    }).style('height', function (d) {
      return "".concat(heights[d[0].tile], "px");
    });
    $g = $annoD.selectAll('.g-anno').data(function (d) {
      return d;
    }).join(function (enter) {
      var g = enter.append('div').attr('class', 'g-anno').attr('data-list', function (d) {
        return d.animal;
      });
      g.append('h3').attr('class', 'animal--name').text(function (d) {
        if (d.display) return d.display;else return d.animal;
      }).attr('data-animal', function (d) {
        return d.animal;
      }).attr('data-id', function (d) {
        return d.camera[0];
      }).on('click', function (d, i, n) {
        return launchModal(d3.select(n[i]));
      });
      var $fs = g.append('fieldset').attr('class', 'animal--list').attr('data-animal', function (d) {
        return d.animal;
      }).attr('tabindex', 0);
      $fs.append('legend').text(function (d) {
        return "Facilities with a ".concat(d.animal, " live stream");
      }).attr('class', 'sr-only');
      return g;
    }).style('grid-area', function (d, i) {
      return "".concat(d.positionY * 2, " / 1 / span 1 / span 1 ");
    });
    setupFacilities($g);
  }
}

function switchFacility() {
  var sel = d3.select(this);
  var cam = sel.attr('data-id');
  var animal = sel.attr('data-animal');
  var exhibit = sel.attr('data-tile');
  var $exhib = $section.select("[data-exhibit=\"".concat(exhibit, "\"]"));
  var $li = null; // set low opacity for non-selected

  if (MOBILE) {
    $li = $mobileAnimals.selectAll('fieldset').filter(function (d, i, n) {
      return d3.select(n[i]).attr('data-animal') === animal;
    }).selectAll('input');
  } else {
    $li = $exhib.selectAll('fieldset').filter(function (d, i, n) {
      return d3.select(n[i]).attr('data-animal') === animal;
    }).selectAll('input');
  }

  $li.property('checked', false);
  $li.selectAll('.video--icon').classed('is-hidden', true);
  sel.property('checked', true);
  sel.select('.video--icon').classed('is-hidden', false); // find which display to switch

  var match = $exhib.selectAll('.cam__display').filter(function (d, i, n) {
    return d3.select(n[i]).attr('data-animal') === animal;
  });
  var type = match.attr('data-type');

  if (type === 'png') {
    match.attr('src', "https://pudding.cool/2020/11/zoo-data/stills/".concat(cam, ".png").concat(clearCache)).attr('data-id', cam).attr('alt', function (d) {
      return "Still image of ".concat(animal, " at ").concat(idToFacilityMap.get(cam));
    });
  } else {
    match.attr('src', "https://pudding.cool/2020/11/zoo-data/output/".concat(cam, ".gif").concat(clearCache)).attr('data-id', cam).attr('alt', function (d) {
      return "Video clip of ".concat(animal, " at ").concat(idToFacilityMap.get(cam));
    });
  }
}

function determineGridRows(d) {
  var last = +d[0].shape.split('')[1];
  var top = TOP_GAP[last];
  var middle = MIDDLE_GAP[last];
  var final = null;
  if (last === 1) final = "".concat(top, " 1fr ").concat(middle);else final = "".concat(top, " repeat(").concat(last - 1, ", minmax(0, 1fr) ").concat(middle, ") minmax(0, 1fr) ").concat(top);
  return final;
}

function loadMaps() {
  var data = nestedData; // create group

  var $group = $islands.selectAll('.g-island').data(data).join(function (enter) {
    return enter.append('div').attr('class', 'g-island').attr('data-exhibit', function (d) {
      return "".concat(d.key);
    }).style('order', function (d, i) {
      return i === 0 ? 0 : i + 1;
    });
  });
  var gridRows = []; // add exhibit tiles

  var $tile = $group.selectAll('.tile').data(function (d) {
    return [d.values];
  }).join(function (enter) {
    // setup grid
    // anywhere between 2 and 5 rows
    var $container = enter.append('div').attr('class', function (d) {
      return "tile tile__".concat(d[0].shape);
    }).style('grid-template-rows', function (d, i) {
      return determineGridRows(d);
    }); // append map artwork

    $container.append('img').attr('class', 'exhibit').attr('src', function (d) {
      return "assets/images/".concat(d[0].tile, "-0.PNG");
    }).attr('data-tile', function (d) {
      return d[0].tile;
    }).attr('aria-hidden', true).style('grid-area', function (d, i, n) {
      var exhibitIndex = d[0].index;
      if (exhibitIndex % 2 === 0 && !MOBILE) return "1 / 2 / ".concat(d.length + 1, " / 4");else if (exhibitIndex === 1 && !MOBILE) return "1 / 2 / ".concat(d.length + 1, " / 4");else return "1 / 1 / ".concat(d.length + 1, " / 3");
    });
    var $exhibits = $container.selectAll('.exhibit');
    $exhibits.nodes().forEach(function (ex) {
      var tile = d3.select(ex).attr('data-tile');
      var h = ex.offsetHeight;
      heights[tile] = h;
    });
    $container.append('img').attr('class', 'exhibit-top').attr('src', function (d) {
      return "assets/images/".concat(d[0].tile, "-2.PNG");
    }).attr('aria-hidden', true).style('grid-area', function (d, i, n) {
      var exhibitIndex = d[0].index;
      if (exhibitIndex % 2 === 0 && !MOBILE) return "1 / 2 / ".concat(d.length + 1, " / 4");else if (exhibitIndex === 1 && !MOBILE) return "1 / 2 / ".concat(d.length + 1, " / 4");else return "1 / 1 / ".concat(d.length + 1, " / 3");
    });
    return $container;
  }); // add videos

  $tile.selectAll('.cam__display').data(function (d) {
    return d;
  }).join(function (enter) {
    // append placeholder images
    enter.append('img').attr('class', 'cam__display').attr('data-id', function (d) {
      return d.first;
    }).attr('data-type', 'png').attr('data-animal', function (d) {
      return d.animal;
    }).attr('tabindex', 0).attr('alt', function (d) {
      return "Video clip of ".concat(d.animal, " at ").concat(idToFacilityMap.get(d.first));
    }).style('justify-self', function (d) {
      return d.positionX === 'R' ? 'start' : 'end';
    }).style('margin-right', function (d) {
      return d.positionX === 'R' ? 0 : "-4%";
    }).style('margin-left', function (d) {
      var right = d.positionX === 'R' ? "-4%" : 0;
      var polarBear = d.tile === 'polar' ? "-40%" : right;
      return polarBear;
    }).attr('src', function (d) {
      return "https://pudding.cool/2020/11/zoo-data/stills/".concat(d.first, ".png").concat(clearCache);
    }).style('grid-area', function (d, i) {
      return findGridArea(d, i);
    }).on('click', function (d, i, n) {
      return launchModal(d3.select(n[i]));
    }).on('keydown', function (d, i, n) {
      var pressed = d3.event.code;

      if (pressed === 'Enter') {
        launchModal(d3.select(n[i]));
      }
    }); //.style('z-index', -10)
    //.on('click', swapSource)
  });
}

function preloadImages() {
  var data = nestedData;
  return new Promise(function (resolve) {
    var allImages = [];

    var _loop = function _loop(i) {
      var imgPromise = (0, _loadImagePromise.default)("assets/images/".concat(data[i].key, "-0.PNG"));
      imgPromise.then(function (img) {
        img.onload(function () {
          if (i === data.length) resolve();
        });
      });
      allImages.push(imgPromise);
    };

    for (var i = 0; i < data.length; ++i) {
      _loop(i);
    }

    Promise.all(allImages).then(resolve).catch(function (e) {
      return console.log("Error in loading images");
    });
  }).catch(function (e) {
    return console.error("Error with preload ".concat(e));
  });
}

function setupTimestamps() {
  return new Promise(function (resolve, reject) {
    d3.json("https://pudding.cool/2020/11/zoo-data/timestamps.json".concat(clearCache)).then(function (res) {
      var timestampData = res.map(function (d) {
        return _objectSpread({}, d, {
          id: +d.id,
          timestamp: +d.timestamp
        });
      }).sort(function (a, b) {
        return d3.descending(a.timestamp, b.timestamp);
      }).shift();
      var currentTime = Date.now();
      var elapsed = d3.timeMinute.count(timestampData.timestamp, currentTime);
      var justUpdated = res.map(function (d) {
        return +d.id;
      });
      $update.text(function () {
        if (elapsed < 60) return "~".concat(elapsed, " minutes ago");else return "~".concat(d3.timeHour.count(timestampData.timestamp, currentTime), " hours ago");
      });
      resolve(justUpdated);
    }).catch(function (err) {
      return reject(err);
    });
  });
}

function loadAssets() {
  return new Promise(function (resolve, reject) {
    try {
      loadMaps(); // setupTimestamps()

      _globe.default.init(mappedData);

      resolve();
    } catch (error) {
      reject(error);
    }
  });
}

function setupScrolls() {
  return new Promise(function (resolve, reject) {
    try {
      setupScroll();
      setupHabitatScroll();
      resize();
      resolve();
    } catch (error) {
      reject(error);
    }
  });
}

function init() {
  (0, _loadData.default)(['assets/data/arrangement.csv', 'assets/data/links.csv']).then(function (response) {
    var data = setupTimestamps().then(function (ts) {
      cleanData(response, ts);
    });
    return data;
  }).then(function () {
    return preloadImages();
  }).then(function () {
    return loadAssets();
  }).then(function () {
    return setupScrolls();
  });
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./load-data":"xZJw","./utils/load-image-promise":"VKu2","intersection-observer":"CRRU","scrollama":"vL5c","./utils/unique":"Na4G","./videoSVG":"drU0","./modal":"modal.js","./globe":"CAFt","promise-polyfill":"gqUM"}],"v9Q8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: "2018_02_stand-up",
  url: "2018/02/stand-up",
  hed: "The Structure of Stand-Up Comedy"
}, {
  image: "2018_04_birthday-paradox",
  url: "2018/04/birthday-paradox",
  hed: "The Birthday Paradox Experiment"
}, {
  image: "2018_11_boy-bands",
  url: "2018/11/boy-bands",
  hed: "Internet Boy Band Database"
}, {
  image: "2018_08_pockets",
  url: "2018/08/pockets",
  hed: "Women’s Pockets are Inferior"
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName("script")[0];
  var script = document.createElement("script");
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === "function") {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open("GET", url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank' rel='noopener'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join("");
  d3.select(".pudding-footer .footer-recirc__articles").html(html);
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"epB2":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _linkFix = _interopRequireDefault(require("./utils/link-fix"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _arrangement = _interopRequireDefault(require("./arrangement"));

var _footer = _interopRequireDefault(require("./footer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $body = d3.select("body");
var previousWidth = 0;

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();

    _arrangement.default.resize();
  }
} // window.addEventListener('scroll', e => {
//   const scrolled = window.pageYOffset
//   const background = d3.select('.background')
//   background.style('top', `${-scrolled * 0.1}px`)
// })


function setupStickyHeader() {
  var $header = $body.select("header");

  if ($header.classed("is-sticky")) {
    var $menu = $body.select(".header__menu");
    var $toggle = $body.select(".header__toggle");
    $toggle.on("click", function () {
      var visible = $menu.classed("is-visible");
      $menu.classed("is-visible", !visible);
      $toggle.classed("is-visible", !visible);
    });
  }
}

function init() {
  // adds rel="noopener" to all target="_blank" links
  (0, _linkFix.default)(); // add mobile class to body tag

  $body.classed("is-mobile", _isMobile.default.any()); // setup resize event

  window.addEventListener("resize", (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader(); // kick off graphic code
  // graphic.init();
  // arrange graphics

  _arrangement.default.init(); // load footer stories


  _footer.default.init();
}

init();
},{"lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./utils/link-fix":"U9xJ","./graphic":"TAPd","./arrangement":"arrangement.js","./footer":"v9Q8"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map